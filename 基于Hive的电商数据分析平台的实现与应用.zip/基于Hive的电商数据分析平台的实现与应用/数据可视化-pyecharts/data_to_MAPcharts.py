import pandas as pd  #pandas是强大的数据处理库
from pyecharts.charts import Map
from pyecharts import options as opts

data = pd.read_csv('result.csv')

data1 =data[data["product_name"]=="nikeshoes4"]

province = list(data1["area_name"])

pv = list(data1["pv"])

list = [list(z) for z in zip(province,pv)]

c = (
    Map(init_opts=opts.InitOpts(width="1000px", height="600px")) #可切换主题
    .set_global_opts(
        title_opts=opts.TitleOpts(title="某个时段内各省商品nikeshoes4点击量分布图    单位:次"),
        visualmap_opts=opts.VisualMapOpts(
            min_=335,
            max_=435,
            range_text = ['颜色区间    商品点击量（次）', ''],  #分区间
            is_piecewise=True,  #定义图例为分段型，默认为连续的图例
            pos_top= "middle",  #分段位置
            pos_left="left",
            orient="vertical",
            split_number=5  #分成5个区间
        )
    )
    .add("PV",list,maptype="china")
    .render("Map4.html")
)

